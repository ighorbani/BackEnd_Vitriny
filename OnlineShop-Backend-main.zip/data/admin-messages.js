exports.financialEvidenceFailed = {
  title: "اطلاعات ارسالی پذیرفته نشد!",
  icon: "construction",
  iconTitle: "اطلاعات شما ناقص بود!",
  iconParagraph:
    "متاسفانه اطلاعات ارسالی شما ناقص بود.شما میتوانید بار دیگر اطلاعات خود را ارسال نمایید.",
  secondTitle: "مشکل کجا بود؟",
  secondParagraph: "آدرس منزل بدون کد پستی بود.",
  image: "",
};
